from controller import Controller

con = Controller()
con.start()